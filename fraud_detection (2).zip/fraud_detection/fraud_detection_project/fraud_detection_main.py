"""
=============================================================
  FRAUD DETECTION IN GOVERNMENT SCHEMES
  Main Pipeline Script
  Author: [Your Name]
  College Project - Big Data & Python
=============================================================
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.ensemble import RandomForestClassifier, IsolationForest
from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import (classification_report, confusion_matrix,
                             roc_auc_score, roc_curve, accuracy_score)
from sklearn.pipeline import Pipeline
import warnings
warnings.filterwarnings('ignore')

# ─────────────────────────────────────────────
# 1. GENERATE SYNTHETIC GOVERNMENT SCHEME DATA
# ─────────────────────────────────────────────
def generate_dataset(n_samples=10000, random_state=42):
    """
    Simulate a government welfare/subsidy scheme dataset.
    Columns represent common fraud indicators.
    """
    np.random.seed(random_state)

    # Legitimate beneficiaries
    n_legit = int(n_samples * 0.88)
    n_fraud = n_samples - n_legit

    # --- Legitimate records ---
    legit = pd.DataFrame({
        'beneficiary_id':   np.arange(1, n_legit + 1),
        'age':              np.random.randint(18, 75, n_legit),
        'annual_income':    np.random.normal(180000, 60000, n_legit).clip(50000, 500000),
        'family_size':      np.random.randint(1, 8, n_legit),
        'land_holding_ac':  np.random.exponential(2, n_legit).clip(0, 20),
        'scheme_amount':    np.random.normal(12000, 3000, n_legit).clip(2000, 25000),
        'claims_per_year':  np.random.randint(1, 4, n_legit),
        'distance_km':      np.random.exponential(15, n_legit).clip(0.5, 200),
        'bank_txn_count':   np.random.randint(2, 30, n_legit),
        'duplicate_aadhaar':np.random.choice([0, 1], n_legit, p=[0.97, 0.03]),
        'ghost_beneficiary':np.zeros(n_legit, dtype=int),
        'is_fraud':         np.zeros(n_legit, dtype=int)
    })

    # --- Fraudulent records ---
    fraud = pd.DataFrame({
        'beneficiary_id':   np.arange(n_legit + 1, n_samples + 1),
        'age':              np.random.randint(1, 120, n_fraud),      # suspicious ages
        'annual_income':    np.random.normal(600000, 200000, n_fraud).clip(300000, 2000000),
        'family_size':      np.random.randint(1, 3, n_fraud),
        'land_holding_ac':  np.random.normal(15, 5, n_fraud).clip(5, 40),
        'scheme_amount':    np.random.normal(45000, 10000, n_fraud).clip(20000, 100000),
        'claims_per_year':  np.random.randint(5, 20, n_fraud),       # inflated claims
        'distance_km':      np.random.uniform(0, 2, n_fraud),        # all very close
        'bank_txn_count':   np.random.randint(0, 3, n_fraud),        # minimal activity
        'duplicate_aadhaar':np.random.choice([0, 1], n_fraud, p=[0.30, 0.70]),
        'ghost_beneficiary':np.random.choice([0, 1], n_fraud, p=[0.40, 0.60]),
        'is_fraud':         np.ones(n_fraud, dtype=int)
    })

    df = pd.concat([legit, fraud], ignore_index=True).sample(frac=1, random_state=42)
    df['scheme_type'] = np.random.choice(
        ['PM-KISAN', 'MGNREGS', 'PMAY', 'Ration Card', 'Scholarship'],
        len(df)
    )
    df['state'] = np.random.choice(
        ['Maharashtra', 'UP', 'Bihar', 'Rajasthan', 'MP', 'Tamil Nadu', 'Gujarat'],
        len(df)
    )
    return df


# ─────────────────────────────────────────────
# 2. EXPLORATORY DATA ANALYSIS
# ─────────────────────────────────────────────
def run_eda(df):
    print("\n" + "="*60)
    print("   EXPLORATORY DATA ANALYSIS")
    print("="*60)
    print(f"\nDataset shape   : {df.shape}")
    print(f"Total records   : {len(df):,}")
    print(f"Fraudulent cases: {df['is_fraud'].sum():,}  ({df['is_fraud'].mean()*100:.1f}%)")
    print(f"Legitimate cases: {(df['is_fraud']==0).sum():,}  ({(df['is_fraud']==0).mean()*100:.1f}%)")
    print("\nMissing values:\n", df.isnull().sum())
    print("\nNumerical Summary:\n", df.describe().T.to_string())

    fig, axes = plt.subplots(2, 3, figsize=(16, 10))
    fig.suptitle("EDA – Fraud Detection in Government Schemes", fontsize=16, fontweight='bold')

    # Fraud distribution
    counts = df['is_fraud'].value_counts()
    axes[0,0].bar(['Legitimate', 'Fraudulent'], counts.values, color=['#2ecc71','#e74c3c'])
    axes[0,0].set_title('Class Distribution')
    axes[0,0].set_ylabel('Count')
    for i, v in enumerate(counts.values):
        axes[0,0].text(i, v + 50, f'{v:,}', ha='center', fontweight='bold')

    # Income distribution
    df[df['is_fraud']==0]['annual_income'].hist(ax=axes[0,1], bins=40, alpha=0.6,
                                                 color='#2ecc71', label='Legit')
    df[df['is_fraud']==1]['annual_income'].hist(ax=axes[0,1], bins=40, alpha=0.6,
                                                 color='#e74c3c', label='Fraud')
    axes[0,1].set_title('Annual Income Distribution')
    axes[0,1].legend()

    # Claims per year
    df.boxplot(column='claims_per_year', by='is_fraud', ax=axes[0,2])
    axes[0,2].set_title('Claims per Year by Fraud Label')
    axes[0,2].set_xlabel('Is Fraud (0=No, 1=Yes)')

    # Scheme type fraud rate
    scheme_fraud = df.groupby('scheme_type')['is_fraud'].mean().sort_values(ascending=False)
    scheme_fraud.plot(kind='bar', ax=axes[1,0], color='#e67e22')
    axes[1,0].set_title('Fraud Rate by Scheme Type')
    axes[1,0].set_ylabel('Fraud Rate')
    axes[1,0].tick_params(axis='x', rotation=30)

    # State-wise fraud
    state_fraud = df.groupby('state')['is_fraud'].mean().sort_values(ascending=False)
    state_fraud.plot(kind='bar', ax=axes[1,1], color='#9b59b6')
    axes[1,1].set_title('Fraud Rate by State')
    axes[1,1].set_ylabel('Fraud Rate')
    axes[1,1].tick_params(axis='x', rotation=30)

    # Correlation heatmap
    num_cols = ['age','annual_income','family_size','land_holding_ac',
                'scheme_amount','claims_per_year','distance_km',
                'bank_txn_count','is_fraud']
    corr = df[num_cols].corr()
    sns.heatmap(corr, ax=axes[1,2], annot=True, fmt='.2f', cmap='RdYlGn',
                linewidths=0.5, annot_kws={'size':7})
    axes[1,2].set_title('Correlation Matrix')

    plt.tight_layout()
    plt.savefig('reports/eda_analysis.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("\n[✓] EDA plot saved → reports/eda_analysis.png")


# ─────────────────────────────────────────────
# 3. FEATURE ENGINEERING
# ─────────────────────────────────────────────
def feature_engineering(df):
    print("\n[✓] Running Feature Engineering...")
    le = LabelEncoder()
    df['scheme_type_enc'] = le.fit_transform(df['scheme_type'])
    df['state_enc']        = le.fit_transform(df['state'])

    # Derived features
    df['income_per_member']  = df['annual_income'] / (df['family_size'] + 1)
    df['claim_to_income']    = df['scheme_amount'] / (df['annual_income'] + 1)
    df['suspicious_score']   = (df['duplicate_aadhaar'] + df['ghost_beneficiary'] +
                                (df['claims_per_year'] > 6).astype(int) +
                                (df['age'] < 5).astype(int) +
                                (df['age'] > 110).astype(int))

    features = ['age','annual_income','family_size','land_holding_ac',
                'scheme_amount','claims_per_year','distance_km',
                'bank_txn_count','duplicate_aadhaar','ghost_beneficiary',
                'scheme_type_enc','state_enc','income_per_member',
                'claim_to_income','suspicious_score']
    return df, features


# ─────────────────────────────────────────────
# 4. MODEL TRAINING & EVALUATION
# ─────────────────────────────────────────────
def train_and_evaluate(df, features):
    print("\n" + "="*60)
    print("   MODEL TRAINING & EVALUATION")
    print("="*60)

    X = df[features]
    y = df['is_fraud']

    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.25, random_state=42, stratify=y
    )

    models = {
        'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
        'Decision Tree':       DecisionTreeClassifier(max_depth=8, random_state=42),
        'Random Forest':       RandomForestClassifier(n_estimators=100, random_state=42,
                                                       n_jobs=-1, class_weight='balanced'),
    }

    scaler  = StandardScaler()
    results = {}

    fig, axes = plt.subplots(1, 3, figsize=(18, 5))
    fig.suptitle("Model Performance – Confusion Matrices", fontsize=14, fontweight='bold')

    for idx, (name, model) in enumerate(models.items()):
        if name == 'Logistic Regression':
            pipe = Pipeline([('scaler', scaler), ('clf', model)])
        else:
            pipe = Pipeline([('clf', model)])

        pipe.fit(X_train, y_train)
        y_pred  = pipe.predict(X_test)
        y_proba = pipe.predict_proba(X_test)[:, 1]

        acc     = accuracy_score(y_test, y_pred)
        auc     = roc_auc_score(y_test, y_proba)
        cv_mean = cross_val_score(pipe, X_train, y_train, cv=5, scoring='roc_auc').mean()

        results[name] = {'model': pipe, 'acc': acc, 'auc': auc, 'cv': cv_mean,
                         'y_pred': y_pred, 'y_proba': y_proba}

        # Confusion matrix plot
        cm = confusion_matrix(y_test, y_pred)
        sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=axes[idx],
                    xticklabels=['Legit','Fraud'], yticklabels=['Legit','Fraud'])
        axes[idx].set_title(f'{name}\nAcc={acc:.3f}  AUC={auc:.3f}')
        axes[idx].set_xlabel('Predicted')
        axes[idx].set_ylabel('Actual')

        print(f"\n{'─'*40}")
        print(f"  {name}")
        print(f"{'─'*40}")
        print(f"  Accuracy       : {acc:.4f}")
        print(f"  ROC-AUC Score  : {auc:.4f}")
        print(f"  CV AUC (5-fold): {cv_mean:.4f}")
        print(classification_report(y_test, y_pred, target_names=['Legitimate','Fraud']))

    plt.tight_layout()
    plt.savefig('reports/confusion_matrices.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("\n[✓] Confusion matrix plot saved → reports/confusion_matrices.png")

    # ROC Curves
    plt.figure(figsize=(8, 6))
    colors = ['#3498db', '#e67e22', '#2ecc71']
    for (name, res), color in zip(results.items(), colors):
        fpr, tpr, _ = roc_curve(y_test, res['y_proba'])
        plt.plot(fpr, tpr, color=color, lw=2,
                 label=f'{name} (AUC={res["auc"]:.3f})')
    plt.plot([0,1],[0,1],'k--', lw=1, label='Random Classifier')
    plt.xlabel('False Positive Rate'); plt.ylabel('True Positive Rate')
    plt.title('ROC Curves – All Models')
    plt.legend(); plt.grid(alpha=0.3)
    plt.savefig('reports/roc_curves.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("[✓] ROC curve plot saved → reports/roc_curves.png")

    return results, X_test, y_test


# ─────────────────────────────────────────────
# 5. FEATURE IMPORTANCE
# ─────────────────────────────────────────────
def plot_feature_importance(results, features):
    rf_model = results['Random Forest']['model'].named_steps['clf']
    importances = rf_model.feature_importances_
    feat_df = pd.DataFrame({'Feature': features, 'Importance': importances})
    feat_df = feat_df.sort_values('Importance', ascending=True).tail(12)

    plt.figure(figsize=(10, 6))
    colors = ['#e74c3c' if imp > 0.08 else '#3498db' for imp in feat_df['Importance']]
    plt.barh(feat_df['Feature'], feat_df['Importance'], color=colors)
    plt.xlabel('Feature Importance Score')
    plt.title('Top Feature Importances – Random Forest')
    plt.grid(axis='x', alpha=0.3)
    plt.tight_layout()
    plt.savefig('reports/feature_importance.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("[✓] Feature importance plot saved → reports/feature_importance.png")


# ─────────────────────────────────────────────
# 6. ANOMALY DETECTION (Unsupervised)
# ─────────────────────────────────────────────
def anomaly_detection(df, features):
    print("\n[✓] Running Isolation Forest (Anomaly Detection)...")
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(df[features])

    iso = IsolationForest(n_estimators=100, contamination=0.12, random_state=42)
    df['anomaly_score'] = iso.fit_predict(X_scaled)
    df['anomaly_label'] = (df['anomaly_score'] == -1).astype(int)

    overlap = (df['is_fraud'] == df['anomaly_label']).mean()
    print(f"  Isolation Forest Agreement with Labels: {overlap*100:.2f}%")

    plt.figure(figsize=(8,5))
    plt.scatter(df[df['anomaly_label']==0]['annual_income'],
                df[df['anomaly_label']==0]['scheme_amount'],
                alpha=0.3, s=8, color='#2ecc71', label='Normal')
    plt.scatter(df[df['anomaly_label']==1]['annual_income'],
                df[df['anomaly_label']==1]['scheme_amount'],
                alpha=0.5, s=15, color='#e74c3c', label='Anomaly')
    plt.xlabel('Annual Income'); plt.ylabel('Scheme Amount')
    plt.title('Isolation Forest – Anomaly Detection')
    plt.legend(); plt.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig('reports/anomaly_detection.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("[✓] Anomaly detection plot saved → reports/anomaly_detection.png")


# ─────────────────────────────────────────────
# 7. SAVE DATA SAMPLES
# ─────────────────────────────────────────────
def save_data_samples(df):
    df.head(500).to_csv('data/sample_dataset.csv', index=False)
    df[df['is_fraud']==1].head(100).to_csv('data/fraud_cases.csv', index=False)
    df[df['is_fraud']==0].head(100).to_csv('data/legitimate_cases.csv', index=False)
    print("[✓] Data samples saved → data/ folder")


# ─────────────────────────────────────────────
# 8. MODEL COMPARISON SUMMARY
# ─────────────────────────────────────────────
def model_summary_chart(results):
    names = list(results.keys())
    accs  = [results[n]['acc'] for n in names]
    aucs  = [results[n]['auc'] for n in names]

    x = np.arange(len(names))
    width = 0.35

    fig, ax = plt.subplots(figsize=(10, 5))
    bars1 = ax.bar(x - width/2, accs, width, label='Accuracy', color='#3498db')
    bars2 = ax.bar(x + width/2, aucs, width, label='ROC-AUC',  color='#e74c3c')

    ax.set_xticks(x); ax.set_xticklabels(names, fontsize=12)
    ax.set_ylim(0.85, 1.02)
    ax.set_ylabel('Score'); ax.set_title('Model Comparison – Accuracy vs AUC')
    ax.legend(); ax.grid(axis='y', alpha=0.3)

    for bar in bars1 + bars2:
        ax.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.003,
                f'{bar.get_height():.3f}', ha='center', va='bottom', fontsize=10)

    plt.tight_layout()
    plt.savefig('reports/model_comparison.png', dpi=150, bbox_inches='tight')
    plt.close()
    print("[✓] Model comparison chart saved → reports/model_comparison.png")


# ─────────────────────────────────────────────
# MAIN ENTRY POINT
# ─────────────────────────────────────────────
if __name__ == '__main__':
    print("\n" + "="*60)
    print("  FRAUD DETECTION IN GOVERNMENT SCHEMES")
    print("  Big Data & Python Project")
    print("="*60)

    print("\n[1/7] Generating synthetic dataset...")
    df = generate_dataset(n_samples=10000)

    print("[2/7] Running EDA...")
    run_eda(df)

    print("[3/7] Feature engineering...")
    df, features = feature_engineering(df)

    print("[4/7] Training models...")
    results, X_test, y_test = train_and_evaluate(df, features)

    print("[5/7] Feature importance...")
    plot_feature_importance(results, features)

    print("[6/7] Anomaly detection...")
    anomaly_detection(df, features)

    print("[7/7] Saving data samples & summary chart...")
    save_data_samples(df)
    model_summary_chart(results)

    print("\n" + "="*60)
    print("  ALL STEPS COMPLETE!")
    print("  Output files saved in reports/ and data/ folders")
    print("="*60)
